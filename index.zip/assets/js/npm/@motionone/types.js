/**
 * Bundled by jsDelivr using Rollup v2.79.2 and Terser v5.39.0.
 * Original file: /npm/@motionone/types@10.17.1/dist/index.es.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
class i{setAnimation(i){this.animation=i,null==i||i.finished.then((()=>this.clearAnimation())).catch((()=>{}))}clearAnimation(){this.animation=this.generator=void 0}}export{i as MotionValue};export default null;
//# sourceMappingURL=/sm/cfe5ec7f2cbb0b575721886bd309ef07082f529023bc4655865add00dff8e9a4.map