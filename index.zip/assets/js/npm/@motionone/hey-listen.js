/**
 * Bundled by jsDelivr using Rollup v2.79.2 and Terser v5.39.0.
 * Original file: /npm/hey-listen@1.0.8/dist/hey-listen.es.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
var n=function(){},t=function(){};export{t as invariant,n as warning};export default null;
//# sourceMappingURL=/sm/560b731c281a919dcdc2466f803aad179ed0b011fc1d2beb83cc69f481c84072.map