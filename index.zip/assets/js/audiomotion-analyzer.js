/*
 * Skypack CDN - audiomotion-analyzer@4.5.2
 *
 * Learn more:
 *   📙 Package Documentation: https://www.skypack.dev/view/audiomotion-analyzer
 *   📘 Skypack Documentation: https://www.skypack.dev/docs
 *
 * Pinned URL: (Optimized for Production)
 *   ▶️ Normal: https://cdn.skypack.dev/pin/audiomotion-analyzer@v4.5.2-hmgaZTbqWXanircCxUW1/mode=imports/optimized/audiomotion-analyzer.js
 *   ⏩ Minified: https://cdn.skypack.dev/pin/audiomotion-analyzer@v4.5.2-hmgaZTbqWXanircCxUW1/mode=imports,min/optimized/audiomotion-analyzer.js
 *
 */

// Browser-Optimized Imports (Don't directly import the URLs below in your application!)
export * from '/-/audiomotion-analyzer@v4.5.2-hmgaZTbqWXanircCxUW1/dist=es2019,mode=imports/optimized/audiomotion-analyzer.js';
export {default} from '/-/audiomotion-analyzer@v4.5.2-hmgaZTbqWXanircCxUW1/dist=es2019,mode=imports/optimized/audiomotion-analyzer.js';
